#!env perl
#Author: autoCreated
my $para_num = "4";
# 配置模板创建时间
my $template_time = "2014-04-02 00:30:32";
my %para;
@array_pre_flag = ();
@array_appendix_flag = ();

$para{Nginx_root_user} = $ARGV[1];
$para{Nginx_root_password} = $ARGV[2];
$para{Nginx_install_package_dir_linux} = $ARGV[3];
$para{Nginx_install_dir_linux} = $ARGV[4];

# 处理检查项中的执行命令

$pre_cmd{9} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"send_timeout\"";
$pre_cmd{14} = "cat $para{Nginx_install_package_dir_linux}/src/http/ngx_http_special_response.c";
$pre_cmd{15} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep \"server_tokens\"";
$pre_cmd{1} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf | grep \"error_log\"";
$pre_cmd{2} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -e \"access_log\\s*logs\\/access\\.log.*\"";
$pre_cmd{3} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep \"log_format\"";
$pre_cmd{4} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep \"allow\"";
$pre_cmd{5} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep \"deny\"";
$pre_cmd{6} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"client_body_timeout\"";
$pre_cmd{7} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"client_header_timeout\"";
$pre_cmd{11} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"limit_zone\"";
$pre_cmd{12} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"limit_rate\"";
$pre_cmd{8} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"keepalive_timeout\"";
$pre_cmd{10} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep \"limit_conn\"";
$pre_cmd{13} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"location\\s*~\\*\\s*\\s*^\\.+\"";

push(@array_pre_flag, 9);
push(@array_pre_flag, 14);
push(@array_pre_flag, 15);
push(@array_pre_flag, 1);
push(@array_pre_flag, 2);
push(@array_pre_flag, 3);
push(@array_pre_flag, 4);
push(@array_pre_flag, 5);
push(@array_pre_flag, 6);
push(@array_pre_flag, 7);
push(@array_pre_flag, 11);
push(@array_pre_flag, 12);
push(@array_pre_flag, 8);
push(@array_pre_flag, 10);
push(@array_pre_flag, 13);

# 处理附录检查项中的执行命令

$appendix_cmd{0} = "$para{Nginx_install_dir_linux}/sbin/nginx -v >/tmp/nginxversion 2>&1
cat /tmp/nginxversion";$appendix_cmd{1} = "cd $para{Nginx_install_package_dir_linux}
./configure --help";
push(@array_appendix_flag, 0);
push(@array_appendix_flag, 1);

# 获取操作系统信息函数
sub get_os_info{
 my %os_info = (
 "hostname"=>"","osname"=>"","osversion"=>"");
 $os_info{"hostname"} = `uname -n`;
 $os_info{"osname"} = `uname -s`;
 $os_info{"osversion"} = `uname -r`;
foreach (%os_info){   chomp;}
return %os_info;}

# 执行命令存入xml文件
sub add_item{
 my ($string, $flag, $command, $value)= @_;
 $string .= "\t\t".'<item flag="'.$flag.'">'."\n";
 $string .= "\t\t\t".'<cmd info="'.$date.'">'."\n";
 $string .= "\t\t\t<command><![CDATA[".$command."]]></command>\n";
 $string .= "\t\t\t<value><![CDATA[".$value."]]></value>\n";
 $string .= "\t\t\t</cmd>\n";
 $string .= "\t\t</item>\n";
return $string;}
 sub generate_xml{
 $ARGC = @ARGV;
if($ARGC lt 5){
 print qq{usag: 66c221be-6ab2-ef53-1589-fe16877914bf.pl <IP> <SU用户名> <SU用户密码> <Nginx安装目录(eg:/usr/local/nginx)> <Nginx安装包目录(eg:/usr/local/nginx-1.5.6)>};
exit;}
my %os_info = get_os_info();
 my $os_name = $os_info{"osname"};
 my $host_name = $os_info{"hostname"};
 my $os_version = $os_info{"osversion"};
 my $date = `date +%y-%m-%d`;
 chomp $date;
 my $ipaddr = $ARGV[0];
 my $xml_string = "";
 $xml_string .='<?xml version="1.0" encoding="UTF-8"?>'."\n";
 $xml_string .= '<result uuid= "'.'66c221be-6ab2-ef53-1589-fe16877914bf'.'" ip="'.$ipaddr.'" template_time= "2014-04-02 00:30:32'.'">'."\n";
 $xml_string .= "\t".'<initcmd>'."\n";
 $xml_string .= "\t\t".'<cmd info="'.$date.'">';
 $xml_string .= '</cmd>'."\n";
 $xml_string .= "\t\t\t".'<command><![CDATA[ ]]></command>'."\n";
 $xml_string .= "\t\t\t".'<value><![CDATA[ ]]></value>'."\n";
 $xml_string .= "\t".'</initcmd>'."\n";
 $xml_string .= "\t".'<security type="auto">'."\n";
 foreach $key (@array_pre_flag){
 $value = $pre_cmd{$key};
 my $tmp_result = `$value`;
 chomp $tmp_result;
 $tmp_result =~ s/>/&gt;/g;
 $xml_string = &add_item( $xml_string, $key, $value, $tmp_result );}
 $xml_string .= "\t</security>\n";
 $xml_string .= "\t".'<security type="display">'."\n";
 foreach $key (@array_appendix_flag){
 $value = $appendix_cmd{$key};
 my $tmp_result = `$value`;
 chomp $tmp_result;
 $tmp_result =~ s/>/&gt;/g;
 $xml_string = &add_item( $xml_string, $key, $value, $tmp_result );}
 $xml_string .= "\t"."</security>"."\n";
 $xml_string .= "</result>"."\n";
 $xmlfile = $ipaddr."_"."66c221be-6ab2-ef53-1589-fe16877914bf"."_chk.xml";
 print $xmlfile."\n";
 open XML,">/tmp/".$xmlfile or die "Cannot create ip.xml:$!";
 print XML $xml_string;
 print "end write xml\n";
 print "DONE ALL\n";}
 generate_xml();
